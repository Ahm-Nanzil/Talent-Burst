document.getElementById("jobpost").addEventListener("submit", function(event) {
    event.preventDefault(); // Prevent the form from submitting the traditional way

    console.log("enter");

   
});
